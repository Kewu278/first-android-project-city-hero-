package com.example.firebaseuser;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.firebaseuser.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {

    private EditText email, pass, name, mobile, address, birthdate, country, city, postalcode;
    private Button Submit;
    String data_email, data_pass, Gender,data_mobile,data_address,data_birthdate,data_country,data_city,data_postalcode,data_name;
    String pattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private FirebaseAuth firebaseAuth;
    private RadioGroup gender;
    private RadioButton male;
    private RadioButton female;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        bind();
        initToolbar();
    }

    public void bind() {

        databaseReference= FirebaseDatabase.getInstance().getReference("User");
        firebaseAuth = FirebaseAuth.getInstance();
        email = findViewById(R.id.email);
        pass = findViewById(R.id.password);

        //bind
        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        pass = (EditText) findViewById(R.id.password);
        mobile = (EditText) findViewById(R.id.mobile);
        address = (EditText) findViewById(R.id.address);
        birthdate = (EditText) findViewById(R.id.birthdate);
        country = (EditText) findViewById(R.id.country);
        city = (EditText) findViewById(R.id.city);
        gender = (RadioGroup) findViewById(R.id.gender);
        postalcode = (EditText) findViewById(R.id.postalcode);
        male = (RadioButton) findViewById(R.id.Male);
        female = (RadioButton) findViewById(R.id.Female);
        Submit =(Button) findViewById(R.id.submit);


        if (male.isChecked()) {
            Gender = "Male";
        }
        if (female.isChecked()) {
            Gender = "Female";
        }
        //giving data to string






        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                User user=new User(data_name,data_email,data_pass,data_mobile,data_birthdate,Gender,data_address,data_country,data_city,data_postalcode);
                final  String  key=FirebaseDatabase.getInstance().getReference("User").push().getKey();
                data_name=name.getText().toString();
                data_email = email.getText().toString();
                data_pass = pass.getText().toString();
                data_mobile = mobile.getText().toString();
                data_address = address.getText().toString();
                data_birthdate = birthdate.getText().toString();
                data_country = country.getText().toString();
                data_city = city.getText().toString();
                data_postalcode = postalcode.getText().toString();


                if(data_name.isEmpty()){
                    name.setError("Enter Your Name");
                }else if(!data_email.matches("[a-zA-Z0-9._-]+@[a-z]+.[a-z]+")){
                    email.setError("Invalid Email Address");
                }else {
                    firebaseAuth.createUserWithEmailAndPassword(data_email, data_pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {

                                Intent intent = new Intent(SignUp.this, SignIn.class);
                                startActivity(intent);
                            } else {

                                Log.e("", "===>" + task.getException());
                            }
                        }
                    });



                    //send data to data base
                    databaseReference.child(key).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(SignUp.this, "Success", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(SignUp.this, SignIn.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(SignUp.this, "Fail", Toast.LENGTH_SHORT).show();
                                Log.d("", "=====>" + task.getException());
                            }
                        }
                    });
                }



            }
        });
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Sign Up");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
