package com.example.firebaseuser.models;

public class User {
    public String name;
    public String email;
    public String pass;
    public String mobile;
    public String birthdate;
    public String gender;
    public String address;
    public String country;
    public String city;
    public String postalcode;

    public User(String name, String email, String pass, String mobile, String birthdate, String gender, String address, String country, String city, String postalcode) {
        this.name = name;
        this.email = email;
        this.pass = pass;
        this.mobile = mobile;
        this.birthdate = birthdate;
        this.gender = gender;
        this.address = address;
        this.country = country;
        this.city = city;
        this.postalcode = postalcode;
    }
}
