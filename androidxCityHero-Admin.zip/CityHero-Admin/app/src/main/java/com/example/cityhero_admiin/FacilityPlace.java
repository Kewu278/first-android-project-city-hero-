package com.example.cityhero_admiin;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FacilityPlace extends AppCompatActivity {

    public static Category_CustomDialog customDialog;
    public static EditText facilityCategory;
    Button btn_showPlace, btn_addNewPlace;

    LinearLayout placeListLayout;
    TextView msg_place, listTitle;
    ListView placeList;

    private List<FacilityPlaceModel> dataList = new ArrayList<>();

    private FirebaseDatabase placeDatabase;
    private DatabaseReference placeReference;

    private FacilityPlaceAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facility_place);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        facilityCategory = (EditText) findViewById(R.id.facilityCategory);
        btn_showPlace = (Button) findViewById(R.id.btn_showPlace);
        btn_addNewPlace = (Button) findViewById(R.id.btn_addNewPlace);

        msg_place = (TextView) findViewById(R.id.place_msg);
        listTitle = (TextView) findViewById(R.id.listTitle);
        placeListLayout = (LinearLayout) findViewById(R.id.placeListLayout);
        placeList = (ListView) findViewById(R.id.place_List);

        placeDatabase = FirebaseDatabase.getInstance();
        placeReference = placeDatabase.getReference("tbl_Place");

        facilityCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customDialog = new Category_CustomDialog(FacilityPlace.this);
                customDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                customDialog.setCancelable(true);
                customDialog.show();
            }
        });

        btn_showPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPlaces();
            }
        });

        btn_addNewPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FacilityPlace.this, NewPlace.class);
                intent.putExtra("CATEGORYID", Category_CustomDialog.categoryID);
                intent.putExtra("CATEGORYNAME", facilityCategory.getText().toString().trim());
                startActivity(intent);
            }
        });
    }

    public void showPlaces() {

        if (!facilityCategory.getText().toString().trim().isEmpty()) {
            facilityCategory.setError(null);
            msg_place.setVisibility(View.GONE);
            placeListLayout.setVisibility(View.VISIBLE);
            btn_addNewPlace.setVisibility(View.VISIBLE);
            listTitle.setText("List of " + facilityCategory.getText().toString());
            placesList();
        } else {
            facilityCategory.setError("Select Category First");
        }

    }

    public void placesList() {
        adapter = new FacilityPlaceAdapter(FacilityPlace.this, dataList);
        placeList.setAdapter(adapter);

        placeReference.child(Category_CustomDialog.categoryID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                dataList.clear();

                for (DataSnapshot placeSnap : dataSnapshot.getChildren()) {
                    FacilityPlaceModel model = placeSnap.getValue(FacilityPlaceModel.class);
                    dataList.add(model);
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

            /*  Place update and delete will be written here.. set on long click listener */
        });
    }

}
