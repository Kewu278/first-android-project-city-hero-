package com.example.cityhero_admiin;

public class FacilityPlaceModel {

    private String placeID;
    private String placeName;
    private String placeAddress;
    private String placeContactNumber;
    private String placeImage;
    private String placeRegisterDate;
    private String placeModifyDate;
    private String placeStatus;

    public FacilityPlaceModel(){}

    public FacilityPlaceModel(String placeID, String placeName, String placeAddress, String placeContactNumber, String placeImage, String placeRegisterDate, String placeModifyDate, String placeStatus) {
        this.placeID = placeID;
        this.placeName = placeName;
        this.placeAddress = placeAddress;
        this.placeContactNumber = placeContactNumber;
        this.placeImage = placeImage;
        this.placeRegisterDate = placeRegisterDate;
        this.placeModifyDate = placeModifyDate;
        this.placeStatus = placeStatus;
    }

    public String getPlaceID() {
        return placeID;
    }

    public String getPlaceName() {
        return placeName;
    }

    public String getPlaceAddress() {
        return placeAddress;
    }

    public String getPlaceContactNumber() {
        return placeContactNumber;
    }

    public String getPlaceImage() {
        return placeImage;
    }

    public String getPlaceRegisterDate() {
        return placeRegisterDate;
    }

    public String getPlaceModifyDate() {
        return placeModifyDate;
    }

    public String getPlaceStatus() {
        return placeStatus;
    }
}
