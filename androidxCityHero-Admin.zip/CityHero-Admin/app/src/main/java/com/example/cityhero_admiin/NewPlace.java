package com.example.cityhero_admiin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Calendar;
import java.util.Date;

public class NewPlace extends AppCompatActivity {

    private EditText place_cat, place_name, placeAddress, placeContact;
    private ImageView placeImage, imageAdd;
    private Button btn_newPlace;

    private String CATEGORYID, CATEGORYNAME;
    private String PLACEID, PLACENAME, PLACEADDR, PLACECONTACT, PLACEREGISTDATE, PLACEMODIFYDATE, PLACEIMAGEURI;

    private Date currentTime;

    private static final int SELECTED_IMAGE = 2;
    private static int flag = 0;
    private Uri placeUri;
    private ProgressDialog dialog;

    private FirebaseDatabase placeDatabase;
    private DatabaseReference placeReference;
    private FirebaseStorage placeStorage;
    private StorageReference storageReference,placeStoreReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_place);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        CATEGORYID = getIntent().getStringExtra("CATEGORYID");
        CATEGORYNAME = getIntent().getStringExtra("CATEGORYNAME");

        place_cat = (EditText) findViewById(R.id.place_cat);
        place_cat.setText(CATEGORYNAME);

        place_name = (EditText) findViewById(R.id.placeName);
        placeAddress = (EditText) findViewById(R.id.placeAddress);
        placeContact = (EditText) findViewById(R.id.placeContact);

        placeImage = (ImageView) findViewById(R.id.placeImage);
        imageAdd = (ImageView) findViewById(R.id.imageAdd);

        btn_newPlace = (Button) findViewById(R.id.btn_newPlace);

        currentTime = Calendar.getInstance().getTime();

        dialog = new ProgressDialog(NewPlace.this);
        dialog.setMessage("Please Wait...");

        placeDatabase = FirebaseDatabase.getInstance();
        placeReference = placeDatabase.getReference("tbl_Place");
        placeStorage = FirebaseStorage.getInstance();
        storageReference = placeStorage.getReference();

        imageAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        btn_newPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateplaceName() && validateplaceAddress() && validateplaceContact() && validatePlaceImage()) {
                    dialog.show();
                    addNewPlace();
                }
            }
        });
    }

    private void openGallery() {
        Intent intent = new Intent();

        intent.setType("image/*");

        intent.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECTED_IMAGE);
    }

    private boolean validateplaceName() {

        if (place_cat.getText().toString().trim().isEmpty()) {
            place_cat.setError("Please Enter Place Name");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateplaceAddress() {

        if (placeAddress.getText().toString().trim().isEmpty()) {
            placeAddress.setError("Please Enter Place Address");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateplaceContact() {

        if (placeContact.getText().toString().trim().isEmpty()) {
            placeContact.setError("Please Enter Place Contact");
            return false;
        } else {
            return true;
        }
    }

    private boolean validatePlaceImage() {
        if (flag == 1) {
            return true;
        } else {
            Toast.makeText(this, "Please Select Place Image...", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private void addNewPlace() {
        PLACEID = placeReference.push().getKey();
        PLACENAME = place_name.getText().toString().trim();
        PLACEADDR = placeAddress.getText().toString().trim();
        PLACECONTACT = placeContact.getText().toString().trim();
        PLACEREGISTDATE = currentTime.toString();
        PLACEMODIFYDATE = currentTime.toString();

        placeStoreReference = storageReference.child("Places").child(CATEGORYID).child(PLACEID);

        UploadTask task = (UploadTask) placeStoreReference.putFile(placeUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Log.e("IS UPLOAD SUCCESS?: ", "YES" );
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e( "IS UPLOAD SUCCESS?:  ","NO" );
            }
        });

        Task<Uri> uriTask = task.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {

                if (task == null){
                    throw task.getException();
                }
                Log.e("Download URL?", placeStoreReference.getDownloadUrl().toString());
                return placeStoreReference.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                Uri uri = task.getResult();
                PLACEIMAGEURI = uri.toString();

                FacilityPlaceModel model = new FacilityPlaceModel(PLACEID,PLACENAME,PLACEADDR,PLACECONTACT,PLACEIMAGEURI,PLACEREGISTDATE,PLACEMODIFYDATE,"Enable");
                placeReference.child(CATEGORYID).child(PLACEID).setValue(model).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        dialog.dismiss();
                        place_name.setText(null);
                        placeAddress.setText(null);
                        placeContact.setText(null);
                        placeImage.setVisibility(View.GONE);
                        imageAdd.setVisibility(View.VISIBLE);
                    }
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SELECTED_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            placeUri = data.getData();
            imageAdd.setVisibility(View.GONE);
            placeImage.setVisibility(View.VISIBLE);
            placeImage.setImageURI(placeUri);
            flag = 1;
        }
    }
}
