package com.example.cityhero_admiin;

public class PlaceCategoryModel {

    public String categoryID;
    public String category;
    public String categoryIcon;

    public PlaceCategoryModel(){}

    public PlaceCategoryModel(String categoryID, String category, String categoryIcon) {
        this.categoryID = categoryID;
        this.category = category;
        this.categoryIcon = categoryIcon;
    }

    public String getCategoryID() {
        return categoryID;
    }

    public String getCategory() {
        return category;
    }

    public String getCategoryIcon() {
        return categoryIcon;
    }
}
