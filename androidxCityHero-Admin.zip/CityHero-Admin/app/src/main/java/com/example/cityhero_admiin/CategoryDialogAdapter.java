package com.example.cityhero_admiin;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class CategoryDialogAdapter extends BaseAdapter {

    Activity activity;
    List<PlaceCategoryModel> dataList;
    LayoutInflater inflater;

    public CategoryDialogAdapter(Activity activity, List<PlaceCategoryModel> dataList) {
        this.activity = activity;
        this.dataList = dataList;
        inflater = LayoutInflater.from(activity);
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.customdialog_listitem,parent,false);

        TextView listViewItem = (TextView) convertView.findViewById(R.id.listViewItem);

        listViewItem.setText(dataList.get(position).getCategory());
        return convertView;
    }
}
