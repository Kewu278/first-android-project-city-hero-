package com.example.cityhero_admiin;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class AddNewsEvents extends Fragment {

    View view;

    Spinner type;
    EditText newsDate, title, venue, description, organiser, organiserNo;
    ImageView newsImage, newsImageAdd;
    Button btn_addNews;

    Date currentTime;

    String NEWSID, TYPE, TITLE;
    public AddNewsEvents() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_add_news_events, container, false);
        bindingWidgets();

        currentTime = Calendar.getInstance().getTime();

        newsDate.setText(currentTime.toString());
        newsDate.setFocusable(false);
        newsDate.setFocusableInTouchMode(false);
        type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (type.getSelectedItem().toString().equals("Events")) {
                    organiser.setVisibility(View.VISIBLE);
                    organiserNo.setVisibility(View.VISIBLE);
                } else if (type.getSelectedItem().toString().equals("-- Select Type --")) {
                    Toast.makeText(getActivity(), "Please Select Either News or Events", Toast.LENGTH_SHORT).show();
                    organiser.setVisibility(View.GONE);
                    organiserNo.setVisibility(View.GONE);
                }else{
                    organiser.setVisibility(View.GONE);
                    organiserNo.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        return view;
    }

    private void bindingWidgets() {
        type = (Spinner) view.findViewById(R.id.type);

        newsDate = (EditText) view.findViewById(R.id.newsDate);
        title = (EditText) view.findViewById(R.id.newsTitle);
        venue = (EditText) view.findViewById(R.id.venue);
        description = (EditText) view.findViewById(R.id.description);
        organiser = (EditText) view.findViewById(R.id.organiser);
        organiserNo = (EditText) view.findViewById(R.id.organiserNo);

        newsImage = (ImageView) view.findViewById(R.id.newsImage);
        newsImageAdd = (ImageView) view.findViewById(R.id.newsimageAdd);

        btn_addNews = (Button) view.findViewById(R.id.btn_addNews);
    }

}
