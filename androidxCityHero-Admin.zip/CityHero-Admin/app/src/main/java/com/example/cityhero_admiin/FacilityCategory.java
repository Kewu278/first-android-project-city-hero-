package com.example.cityhero_admiin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.List;

public class FacilityCategory extends AppCompatActivity {

    private static final int SELECTED_IMAGE = 1;
    private static int flag = 0;

    EditText categoryName;
    ImageView categoryIcon;
    Button btn_categoryAdd;
    ListView categoryList;

    private String cat_id, cat_Name, cat_icon;
    private Uri iconUri;
    private List<PlaceCategoryModel> dataList = new ArrayList<>();
    FacilityCategoryAdapter adapter;

    private FirebaseDatabase categoryDatabase;
    private DatabaseReference categoryReference;
    private FirebaseStorage categoryStorage;
    private StorageReference storageReference, catStoreReference;

    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facility_category);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        categoryDatabase = FirebaseDatabase.getInstance();
        categoryReference = categoryDatabase.getReference("tbl_PlaceCategory");
        categoryStorage = FirebaseStorage.getInstance();
        storageReference = categoryStorage.getReference();

        categoryName = (EditText) findViewById(R.id.categoryName);
        categoryIcon = (ImageView) findViewById(R.id.categoryIcon);
        btn_categoryAdd = (Button) findViewById(R.id.btn_addCategory);
        categoryList = (ListView) findViewById(R.id.categoryList);

        loadCategory();

        dialog = new ProgressDialog(FacilityCategory.this);
        dialog.setMessage("Please Wait...");

        categoryIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        btn_categoryAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateCategoryName() && validateCategoryIcon()) {
                    dialog.show();
                    registerCategory();

                }
            }
        });
    }

    private void loadCategory() {
        adapter = new FacilityCategoryAdapter(FacilityCategory.this, dataList);
        categoryList.setAdapter(adapter);
        categoryReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                dataList.clear();
                for (DataSnapshot category : dataSnapshot.getChildren()) {
                    PlaceCategoryModel model = category.getValue(PlaceCategoryModel.class);
                    dataList.add(model);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        /* Category update and delete code will be come here.....Set on long click listener*/
    }

    private boolean validateCategoryName() {
        cat_Name = categoryName.getText().toString().trim();

        if (TextUtils.isEmpty(cat_Name)) {
            categoryName.setError("Enter Category Name");
            return false;
        } else {
            return true;
        }
    }

    private boolean validateCategoryIcon() {
        if (flag == 1) {
            return true;
        } else {
            Toast.makeText(this, "Select Icon for Category", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private void openGallery() {
        Intent intent = new Intent();

        intent.setType("image/*");

        intent.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECTED_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SELECTED_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            iconUri = data.getData();
            categoryIcon.setImageURI(iconUri);
            flag = 1;
        }
    }

    public void registerCategory() {
        cat_id = categoryReference.push().getKey();
        cat_Name = categoryName.getText().toString().trim();
        catStoreReference = storageReference.child("Place Category").child(cat_Name);

        UploadTask task = (UploadTask) catStoreReference.putFile(iconUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Log.e("Is Upload Success?", "Yes");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                dialog.dismiss();
                Log.e("Upload Error:", e.toString() + "");
            }
        });

        Task<Uri> uriTask = task.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if (task == null) {
                    throw task.getException();
                }
                Log.e("Download URL?", catStoreReference.getDownloadUrl().toString());
                return catStoreReference.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                Uri uri = task.getResult();
                cat_icon = uri.toString();

                PlaceCategoryModel placeCategoryModel = new PlaceCategoryModel(cat_id, cat_Name, cat_icon);
                categoryReference.child(cat_id).setValue(placeCategoryModel).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        dialog.dismiss();
                        categoryName.setText(null);
                        categoryIcon.setImageResource(R.drawable.imageadd);
                    }
                });
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.notifyDataSetChanged();
    }
}
