package com.example.cityhero_admiin;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Category_CustomDialog extends Dialog {

    public Activity activity;

    private ListView category_list;

    DatabaseReference databaseReference;

    List<PlaceCategoryModel> dataList = new ArrayList<>();

    public static String categoryID;

    public Category_CustomDialog(Activity activity){
        super(activity);
        this.activity = activity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.category_dialog_layout);

        category_list = (ListView) findViewById(R.id.category_List);

        databaseReference = FirebaseDatabase.getInstance().getReference("tbl_PlaceCategory");
        final CategoryDialogAdapter adapter = new CategoryDialogAdapter(activity,dataList);
        category_list.setAdapter(adapter);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                dataList.clear();;

                for (DataSnapshot listSnapshot : dataSnapshot.getChildren()){
                    PlaceCategoryModel model = listSnapshot.getValue(PlaceCategoryModel.class);
                    dataList.add(model);
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        category_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PlaceCategoryModel model = dataList.get(position);
                categoryID = model.getCategoryID();

                FacilityPlace.facilityCategory.setText(model.getCategory());

                FacilityPlace.customDialog.dismiss();
            }
        });
    }
}
