package com.example.cityhero_admiin;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

public class FacilityPlaceAdapter extends BaseAdapter {

    Activity activity;
    List<FacilityPlaceModel> dataList;
    LayoutInflater inflater;

    public FacilityPlaceAdapter(FacilityPlace facilityPlace, List<FacilityPlaceModel> dataList) {
        this.activity = facilityPlace;
        this.dataList = dataList;
        inflater = LayoutInflater.from(activity);
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.placelist_items, parent, false);
        TextView place_Name = convertView.findViewById(R.id.place_Name);
        TextView place_Addr = convertView.findViewById(R.id.place_Address);
        TextView place_Contact = convertView.findViewById(R.id.place_Contact);
        ImageView place_Image = convertView.findViewById(R.id.place_Image);

        place_Name.setText(dataList.get(position).getPlaceName());
        place_Addr.setText(dataList.get(position).getPlaceAddress());
        place_Contact.setText(dataList.get(position).getPlaceContactNumber());
        Glide.with(activity).load(dataList.get(position).getPlaceImage()).into(place_Image);

        Animation animation= AnimationUtils.loadAnimation(activity,R.anim.fade_in);
        convertView.setAnimation(animation);

        return convertView;
    }
}
