package com.example.cityhero_admiin;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

public class FacilityCategoryAdapter extends BaseAdapter {
    private Activity activity;
    private List<PlaceCategoryModel> dataList;
    private LayoutInflater inflater;

    public FacilityCategoryAdapter(Activity activity, List<PlaceCategoryModel> dataList){
        this.activity = activity;
        this.dataList = dataList;
        inflater = LayoutInflater.from(activity);
    }


    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = inflater.inflate(R.layout.categorylist_items,parent,false);
        ImageView cat_icon = (ImageView) view.findViewById(R.id.cat_icon);
        TextView cat_name = (TextView) view.findViewById(R.id.cat_name);

        PlaceCategoryModel model = dataList.get(position);
        cat_name.setText(model.getCategory());
        Glide.with(activity).load(model.getCategoryIcon()).into(cat_icon);
        return view;
    }
}
