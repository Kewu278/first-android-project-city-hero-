package com.example.cityhero_admiin;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login_Activity extends AppCompatActivity implements View.OnClickListener {

    protected static final String ADMINID = "AdminCH";
    protected static final String ADMINPASSWORD = "cityHeroAdmin@100";

    TextView txtmessage;
    EditText adminID,adminPassword;
    Button btn_signIn;
    TextInputLayout txtPassword;

    private String id,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_);

        txtmessage = (TextView)findViewById(R.id.txt_invalidmsg);

        adminID = (EditText)findViewById(R.id.adminID);
        adminPassword = (EditText)findViewById(R.id.adminPassword);

        txtPassword = (TextInputLayout) findViewById(R.id.edit_password);
        btn_signIn = (Button)findViewById(R.id.btn_signin);
        btn_signIn.setOnClickListener(this);

        adminPassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                adminPassword.setError(null);
                txtPassword.setPasswordVisibilityToggleEnabled(true);
            }
        });
    }

    public boolean validateAdminID(){
        id = adminID.getText().toString().trim();

        if (TextUtils.isEmpty(id)){
            adminID.setError("Enter Valid ID");
            return false;
        }else{
            adminID.setError(null);
            return true;
        }
    }

    public boolean validateAdminPassword(){
        password = adminPassword.getText().toString();

        if (TextUtils.isEmpty(password)){
            txtPassword.setPasswordVisibilityToggleEnabled(false);
            adminPassword.setError("Enter Valid Password");
            return false;
        }else{
            txtPassword.setPasswordVisibilityToggleEnabled(true);
            adminPassword.setError(null);
            return true;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_signin:
                if (validateAdminID() && validateAdminPassword()){
                    id = adminID.getText().toString().trim();
                    password = adminPassword.getText().toString();

                    if ((TextUtils.equals(id,ADMINID)) && (TextUtils.equals(password,ADMINPASSWORD)) ){

                        Toast.makeText(this, "Welcome Admin!!!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Login_Activity.this,MainActivity.class));
                        finish();

                    }else{
                        txtmessage.setVisibility(View.VISIBLE);
                    }
                }
                break;
        }
    }
}
